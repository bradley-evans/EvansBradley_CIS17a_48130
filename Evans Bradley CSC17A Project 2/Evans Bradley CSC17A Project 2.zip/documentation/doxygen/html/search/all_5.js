var searchData=
[
  ['verb',['Verb',['../class_verb.html',1,'Verb'],['../class_verb.html#a897fe299ba0209fc936813370c5118c5',1,'Verb::Verb()']]]
];
