var searchData=
[
  ['noun',['Noun',['../class_noun.html',1,'Noun'],['../class_noun.html#a46f4325861fbf419e1869ac5d3bfa0dd',1,'Noun::Noun()']]]
];
