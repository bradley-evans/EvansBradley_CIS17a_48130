var searchData=
[
  ['setdec',['setDec',['../class_suspect.html#ab1d6fc6654251e0d7be168a065b0c089',1,'Suspect']]],
  ['setexh',['setExh',['../class_suspect.html#ac32cf4eef49f6add1b3a1946857822e9',1,'Suspect']]],
  ['sethon',['setHon',['../class_suspect.html#a4964ec0d349e373cf7b0b81de2c19a95',1,'Suspect']]],
  ['setint',['setInt',['../class_suspect.html#ade8b63d306298a739bc06e3eda6318b1',1,'Suspect']]],
  ['setloy',['setLoy',['../class_suspect.html#a24c926adc193d31a4e896374681c737f',1,'Suspect']]],
  ['settru',['setTru',['../class_suspect.html#a4be2a662a5871ba05a28f59ca4af26c2',1,'Suspect']]]
];
