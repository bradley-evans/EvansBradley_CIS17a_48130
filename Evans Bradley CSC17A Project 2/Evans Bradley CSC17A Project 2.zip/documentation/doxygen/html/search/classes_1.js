var searchData=
[
  ['game',['Game',['../class_game.html',1,'']]],
  ['gamestate',['Gamestate',['../struct_gamestate.html',1,'']]]
];
