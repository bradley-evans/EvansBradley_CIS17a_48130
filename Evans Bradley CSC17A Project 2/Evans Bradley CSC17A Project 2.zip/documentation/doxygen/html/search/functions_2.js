var searchData=
[
  ['parsenoun',['parseNoun',['../class_noun.html#a9b1b22ddfce50782fce9b2ed8744e1af',1,'Noun']]],
  ['parseverb',['parseVerb',['../class_verb.html#aec80586ba71f2f2fda1acd205edb7544',1,'Verb']]]
];
