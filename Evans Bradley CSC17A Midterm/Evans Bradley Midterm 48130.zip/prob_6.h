/* 
 * File:   prob_1.h
 * Author: Bradley Evans
 *
 * Created on October 24, 2014, 2:00 AM
 */

#ifndef PROB_6_H
#define	PROB_6_H

#include <iostream>
using namespace std;

void solution_6();

#endif	/* PROB_6_H */

