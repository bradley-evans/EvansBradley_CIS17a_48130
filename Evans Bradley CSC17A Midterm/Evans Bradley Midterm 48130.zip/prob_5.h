/* 
 * File:   prob_1.h
 * Author: Bradley Evans
 *
 * Created on October 24, 2014, 2:00 AM
 */

#ifndef PROB_5_H
#define	PROB_5_H

#include <iostream>
#include <limits> 
#include "evans_standard.h"
using namespace std;

void solution_5();
double factorial(int n);

#endif	/* PROB_5_H */

