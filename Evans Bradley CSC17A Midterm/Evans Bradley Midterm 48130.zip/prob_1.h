/* 
 * File:   prob_1.h
 * Author: Bradley Evans
 *
 * Created on October 24, 2014, 2:00 AM
 */

#ifndef PROB_1_H
#define	PROB_1_H

#include <iostream>
#include <iomanip>
#include <cctype>
using namespace std;



void solution_1();
void getAcctNum ();
void makeWithdraw();
void makeDeposit();
void viewBal();

#endif	/* PROB_1_H */

