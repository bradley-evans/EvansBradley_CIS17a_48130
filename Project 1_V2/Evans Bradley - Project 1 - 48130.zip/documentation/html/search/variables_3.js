var searchData=
[
  ['hatred',['hatred',['../struct_suspect__s.html#aaf6a1c91ce381e01b2bee299bec337dc',1,'Suspect_s']]],
  ['honest',['honest',['../struct_suspect__s.html#a20774be3bfbe97a7ff6de44ebf7c324d',1,'Suspect_s']]]
];
