var searchData=
[
  ['truthtold',['truthtold',['../struct_suspect__s.html#af2beebc000e0420ebb06ddf40a6a08ca',1,'Suspect_s']]]
];
