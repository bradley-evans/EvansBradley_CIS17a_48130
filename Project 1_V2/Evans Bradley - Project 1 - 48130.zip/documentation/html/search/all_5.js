var searchData=
[
  ['interrogation_3a_20a_20game_20about_20questioning_20suspects',['Interrogation: A Game about Questioning Suspects',['../index.html',1,'']]],
  ['initialize',['initialize',['../class_gameclock.html#a8ae4ef456d9bb6459b2cb39a5ac151f5',1,'Gameclock']]]
];
