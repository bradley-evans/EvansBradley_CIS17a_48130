var searchData=
[
  ['score',['score',['../struct_highscore.html#ac9dae3cd8bbd8b55fd4611203b10e082',1,'Highscore']]],
  ['silence',['silence',['../struct_suspect__s.html#a2bb8b0ca3470b4dfb856f631b7ac5da0',1,'Suspect_s']]]
];
