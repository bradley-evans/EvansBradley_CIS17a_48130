var searchData=
[
  ['dice',['Dice',['../class_dice.html',1,'']]]
];
