var searchData=
[
  ['pain',['pain',['../struct_suspect__s.html#a7b6fc79ab716033592c1f3b0e8797e57',1,'Suspect_s']]]
];
