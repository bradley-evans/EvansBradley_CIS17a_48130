var searchData=
[
  ['deception',['deception',['../struct_suspect__s.html#a7480c1e6ea9e13fc672be23178e7802b',1,'Suspect_s']]],
  ['dice',['Dice',['../class_dice.html',1,'']]],
  ['distort',['distort',['../struct_suspect__s.html#aa3f819eebfe94a0a230be569ddab0d52',1,'Suspect_s']]],
  ['distract',['distract',['../struct_suspect__s.html#a2d2d292796fa66c5fa553cb55beb8131',1,'Suspect_s']]],
  ['downtick',['downtick',['../class_gameclock.html#a642de6c98f69fca5512f50212f631cb3',1,'Gameclock']]]
];
