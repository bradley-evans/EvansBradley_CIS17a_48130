var searchData=
[
  ['exhaustion',['exhaustion',['../struct_suspect__s.html#a138b9d4dc4a3dc4f897ea2986fdc337a',1,'Suspect_s']]]
];
