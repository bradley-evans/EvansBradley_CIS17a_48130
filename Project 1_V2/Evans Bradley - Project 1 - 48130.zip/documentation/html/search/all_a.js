var searchData=
[
  ['roll',['roll',['../class_dice.html#a64f62a5c9aab9284f7f495f13b667d18',1,'Dice']]]
];
