var searchData=
[
  ['minimize',['minimize',['../struct_suspect__s.html#a0bdb6fa57ffea54acd294d24b749fb95',1,'Suspect_s']]]
];
