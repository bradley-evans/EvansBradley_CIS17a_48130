var searchData=
[
  ['interrogation_3a_20a_20game_20about_20questioning_20suspects',['Interrogation: A Game about Questioning Suspects',['../index.html',1,'']]]
];
