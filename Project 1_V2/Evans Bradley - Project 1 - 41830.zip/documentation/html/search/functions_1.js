var searchData=
[
  ['downtick',['downtick',['../class_gameclock.html#a642de6c98f69fca5512f50212f631cb3',1,'Gameclock']]]
];
