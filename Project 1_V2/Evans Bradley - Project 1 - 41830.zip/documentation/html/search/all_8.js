var searchData=
[
  ['name',['name',['../struct_highscore.html#a8213656e68dfb25b0a17519b5f62d5ec',1,'Highscore']]]
];
