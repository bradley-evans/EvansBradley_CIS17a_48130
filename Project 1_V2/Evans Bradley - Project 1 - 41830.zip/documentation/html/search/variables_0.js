var searchData=
[
  ['comply',['comply',['../struct_suspect__s.html#a8f5208d18939f62750ffe03a479023ff',1,'Suspect_s']]]
];
