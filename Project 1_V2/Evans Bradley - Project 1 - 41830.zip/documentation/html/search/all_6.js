var searchData=
[
  ['liestold',['liestold',['../struct_suspect__s.html#ac6bb03316c123969e86e76ca78c3e010',1,'Suspect_s']]]
];
